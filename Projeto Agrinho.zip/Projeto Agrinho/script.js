// Seleciona os elementos do carrossel
const carrosselSlide = document.querySelector('.carrossel-slide');
const carrosselImagens = document.querySelectorAll('.carrossel-slide img');

// Define variáveis para controlar o carrossel
let contador = 0;
const tamanho = carrosselImagens[0].clientWidth;

// Posiciona o carrossel na imagem inicial
carrosselSlide.style.transform = 'translateX(' + (-tamanho * contador) + 'px)';

// Função para avançar no carrossel automaticamente
function avancarCarrossel() {
    if (contador >= carrosselImagens.length - 1) {
        contador = -1;
    }
    carrosselSlide.style.transition = "transform 1s ease-in-out";
    contador++;
    carrosselSlide.style.transform = 'translateX(' + (-tamanho * contador) + 'px)';
}

// Avançar automaticamente no carrossel
setInterval(avancarCarrossel, 5000);
